/*
  Liste aller Alltagsstudien.

  Neue Studien einfach am ENDE der Liste hinzufügen.
  Dadurch erscheinen sie automatisch unter "Neueste"
  ganz vorne.

  Erwartete Dateien:

    pics/alltagsstudien/<slug>.png
    md/alltagsstudien/<slug>.md

  Optional:
    datum
    link
    linkText

  "datum" wird im ISO-Format YYYY-MM-DD erwartet.
*/

const alltagsstudienListe = [

  {
    slug: "unterscheidung-satire-nachrichten",
    titel: "Schwierige Unterscheidung von Satire- und Nachrichtensendungen",
    datum: "2026-10-03"
  },

  {
    slug: "limonade-preise",
    titel: "Bemerkenswerte Preisgestaltung im Discounter",
    datum: "2026-10-05"
  },

  {
    slug: "videoschiedsrichter",
    titel: "Mögliche Kontrolle von Videoschiedsrichtern",
    datum: "2026-10-07"
  },

  {
    slug: "regierung-diskreditierung",
    titel: "Rekursive Regierungskritik",
    datum: "2026-10-09"
  },

  {
    slug: "amazon-cheap-cds",
    titel: "Unstimmigkeit in der Produktsuche",
    datum: "2026-10-11",
    link: "https://www.amazon.de/s?i=popular&rh=n%3A255882%2Cp_36%3A-500&s=featured-rank&content-id=amzn1.sym.fc4f3753-af8e-4288-9354-f00cdcb2b673&pd_rd_r=90bcb95b-5d01-406b-a1b8-edb1ee93c9f9&pd_rd_w=M0pmc&pd_rd_wg=jTSWs&pf_rd_p=fc4f3753-af8e-4288-9354-f00cdcb2b673&pf_rd_r=NERF60648PVA1X44KV0X&ref=Oct_d_oup_S",
    linkText: "Überprüfe die aktuellen Treffer"
  },

  {
    slug: "duschgel-kombination",
    titel: 'Aus "2 in 1" wird "3 in 1"',
    datum: "2026-10-13"
  },

  {
    slug: "homeoffice-arbeitsunfall",
    titel: "Arbeitsunfälle im Home-Office",
    datum: "2026-10-15"
  },

  {
    slug: "englisch-jugendsprache",
    titel: "Mögliche Korrelation zwischen Verwendung von Jugendsprache und Englischnote",
    datum: "2026-10-17"
  },

  {
    slug: "scientology-flyer",
    titel: "Immense Verbesserung dank Scientology",
    datum: "2026-10-19"
  },

  {
    slug: "kassa-warteschlangen",
    titel: "Die Wahl der falschen Supermarktkasse",
    datum: "2026-10-21"
  },

  {
    slug: "amazon-cd-preise",
    titel: "Preisabweichungen im Versandhandel",
    datum: "",
    link: "https://www.amazon.de/Shape-Fluidity-Digipak-Dool/dp/B08LS9VYGF/ref=sr_1_3?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&crid=V5IBWTPQ120Z&dib=eyJ2IjoiMSJ9.5w82_zdt_kO8RzGRNLIo6xotFtzsR9VLpULHdVVCPqcznzdwNnU5XyYWYllIl368Atr9pWDmOnraBxUeoZop72-LWCsdt8RaBR0akJpXEpN-tP21LcNJZLglB4-WhM1B9hvB_DIyRXoWtkwYmdNatGYcTnvGEZqxTwGB4wrN6YiIX_hg47-4ezksixawYy3yvw4xyIvFpVfBPoe5J393igUhPFM9s3C2sbqeesIvYwlU.MpOwAxiTsuE27XJJHgDw8_csAPylUfKBEugTRve5CYI&dib_tag=se&keywords=dool+cd&qid=1788173090&sprefix=dool+cd%2Caps%2C109&sr=8-3",
    linkText: "Überprüfe einen Preis"
  },

  {
    slug: "windows-suche",
    titel: "Auffälligkeiten bei der lokalen Programmsuche",
    datum: ""
  },

  {
    slug: "fussball-handball",
    titel: "Unerwartete Korrelationen zwischen Sportarten",
    datum: ""
  },

  {
    slug: "verkehr-fahrbahnen",
    titel: "Die Wahl der falschen Fahrbahn im Straßenverkehr",
    datum: ""
  },

  {
    slug: "diskret-telefonieren",
    titel: "Mögliche Innovationen zur diskreten Telefonie",
    datum: ""
  },

  {
    slug: "institut-professorentitel",
    titel: "Mögliche Verbesserung der Außenwahrnehmung durch Professorentitel",
    datum: ""
  },

  {
    slug: "ungewoehnliche-gliedmassen",
    titel: "Zunahme von Fällen von Menschen mit einer ungewöhnlichen Anzahl von Gliedmaßen",
    datum: ""
  },

  {
    slug: "verzoegerung-im-betriebsablauf",
    titel: "Die ominöse Verzögerung im Betriebsablauf",
    datum: ""
  },

  {
    slug: "frisch-gewischt",
    titel: "Warnungen vor frisch gewischtem Boden",
    datum: ""
  },

  {
    slug: "allgemeine-geschaeftsbedingungen",
    titel: "Details von allgemeinen Geschäftsbedingungen",
    datum: ""
  },

  {
    slug: "foerderantraege",
    titel: "Förderantrag für Studie über Förderanträge",
    datum: ""
  },

    {
    slug: "kaffee-studien",
    titel: "Wechselnde Wirkungen von Kaffee je nach Studienlage",
    datum: ""
  },

  {
    slug: "selbstevaluation-institut",
    titel: "Unabhängige Evaluation des Instituts durch das Institut",
    datum: ""
  },

  {
    slug: "arzt-oder-apotheker",
    titel: "Mögliche Informationskreisläufe zwischen Arzt und Apotheker",
    datum: ""
  },

  {
    slug: "hotline-warteschleife",
    titel: "Die Wichtigkeit von Anliegen in der Warteschleife",
    datum: ""
  },

  {
    slug: "zeitmanagement-seminar",
    titel: "Überziehung von Zeitmanagement-Seminaren",
    datum: ""
  },

  {
    slug: "shrinkflation",
    titel: "Gleichbleibende Preise bei sinkendem Gegenwert",
    datum: ""
  },

  {
    slug: "cookie-banner",
    titel: "Mögliche Benachteiligung bei Ablehnung von Cookies",
    datum: ""
  },

  {
    slug: "wetter-app-regenwahrscheinlichkeit",
    titel: "Regen trotz 0% Regenwahrscheinlichkeit",
    datum: ""
  },

  {
    slug: "fortschrittsbalken-99-prozent",
    titel: "Die Dauer des letzten Prozents",
    datum: ""
  },
  
  {
    slug: "regenschirm-entscheidung",
    titel: "Veränderung der Regenwahrscheinlichkeit durch Verzicht auf den Regenschirm",
    datum: ""
  },

  {
    slug: "iq-entwicklung",
    titel: "Möglicher Anstieg des IQ durch Beibehaltung der eigenen Intelligenz",
    datum: ""
  },

   {
    slug: "usb-stecker",
    titel: "Die dritte Seite des USB-Steckers",
    datum: ""
  },

  {
    slug: "selbstbedienungskassa",
    titel: "Arbeitsleistung von Kundschaft an der Selbstbedienungskassa",
    datum: ""
  },

  {
    slug: "uebrige-schrauben",
    titel: "Übrig gebliebene Schrauben nach dem Möbelaufbau",
    datum: ""
  },

  {
    slug: "verschwundene-socken",
    titel: "Das Verschwinden einzelner Socken",
    datum: ""
  },

  {
    slug: "vielleicht-spaeter",
    titel: "Die Dauer von „Später erinnern“",
    datum: ""
  },

  {
    slug: "newsletter-abmeldung",
    titel: "Abmeldung von nie abonnierten Newslettern",
    datum: ""
  },

  {
    slug: "baustelle-ohne-arbeiter",
    titel: "Beobachtungen auf einer Baustelle ohne Arbeiter",
    datum: ""
  },

  {
    slug: "fitnessstudio-mitgliedschaft",
    titel: "Fitness durch Mitgliedschaft",
    datum: ""
  },

  {
    slug: "unbemannter-raumflug",
    titel: "Mögliche Unbemanntheit eines rein weiblich besetzten Raumflugs",
    datum: ""
  },

  {
    slug: "zug-durchsage",
    titel: "Verhalten bei Zugdurchsagen ohne Kinderwagen",
    datum: ""
  },

  {
    slug: "flugzeug-aussteigen",
    titel: "Zeitgewinn und Zeitverlust beim Aussteigen aus dem Flugzeug",
    datum: ""
  },

   {
    slug: "captcha-menschentest",
    titel: "Menschlichkeitstests, die Menschen nicht bestehen",
    datum: ""
  },

  {
    slug: "wlan-passwort",
    titel: "Lesbarkeit von Router-Passwörtern",
    datum: ""
  },

  {
    slug: "hier-oeffnen",
    titel: "Die Wirksamkeit der Aufschrift „Hier öffnen“",
    datum: ""
  },

  { 
    slug: "paketzustellung",
    titel: "Das Anwesenheitsparadoxon bei der Paketzustellung",
    datum: ""
  },

  {
    slug: "pizzakarton",
    titel: "Altpapier oder Restmüll: Der Pizzakarton",
    datum: ""
  },

  {
    slug: "tueren-schliessen-knopf",
    titel: "Wirkung des „Türen schließen“-Knopfes im Aufzug",
    datum: ""
  },

  {
    slug: "elfmeter-tormann",
    titel: "Das Bewegungsparadoxon beim Elfmeter",
    datum: ""
  },

  {
    slug: "wegweiser-gehzeit",
    titel: "Überschätzte Gehzeiten auf Wegweisern",
    datum: ""
  },

  {
    slug: "trainer-vom-sofa",
    titel: "Treffsicherheit von Trainern vom Sofa",
    datum: ""
  },

  {
    slug: "abseitsregel",
    titel: "Erklärbarkeit der Abseitsregel",
    datum: ""
  },

  {
    slug: "kommentatorfloskeln",
    titel: "„Das Spiel ist noch nicht entschieden“",
    datum: ""
  },

  {
    slug: "tennis-zaehlweise",
    titel: "Warum 40 und nicht 45?",
    datum: ""
  },

  {
    slug: "marathon-distanz",
    titel: "Die ungeklärten 195 Meter beim Marathon",
    datum: ""
  },

  {
    slug: "fussball-maenner-frauen",
    titel: "Zuschauerpräferenzen zwischen Männer- und Frauenfußball",
    datum: ""
  },

  {
    slug: "koalitionsparteien-zukunft",
    titel: "Erforderliche Zahl von Koalitionsparteien in der Zukunft",
    datum: ""
  },

  {
    slug: "nichtwaehler-partei",
    titel: "Die Partei der Nichtwähler",
    datum: ""
  },

  {
    slug: "wahlversprechen-halbwertszeit",
    titel: "Die Halbwertszeit von Wahlversprechen",
    datum: ""
  },

  {
    slug: "interviews-antworten",
    titel: "Antwortquote in politischen Interviews",
    datum: ""
  },

  {
    slug: "wahlprogramm",
    titel: "Lesbarkeit und Zustimmung bei Wahlprogrammen",
    datum: ""
  },

  {
    slug: "arbeitsgruppe",
    titel: "Arbeitsgruppen zur Prüfung von Arbeitsgruppen",
    datum: ""
  },

  {
    slug: "parteitag-zustimmung",
    titel: "Die 1,7 Prozent beim Parteitag",
    datum: ""
  },

];


// Nur veröffentlichte Studien zurückgeben.
//
// Wie bei den Ratgebern gilt:
// - Datum in der Vergangenheit/heute -> sichtbar
// - Datum in der Zukunft -> unsichtbar
// - leeres Datum -> aktuell ebenfalls unsichtbar,
//   weil noch kein Veröffentlichungsdatum gesetzt wurde.

function holeVerfuegbareAlltagsstudien() {

  return alltagsstudienListe.filter(
    studie =>
      istDatumErreicht(studie.datum)
  );

}

/*
  Wandelt ein ISO-Datum (YYYY-MM-DD, z.B. aus
  data/veroeffentlichungen.json) für die Anzeige in die deutsche
  Lesefassung um, z.B. "2028-08-22" -> "22. August 2028".

  ISO wird in der JSON-Datei bewusst verwendet, weil es sich zuverlässig
  parsen und vergleichen lässt (new Date("2028-08-22") funktioniert
  überall gleich) - anders als deutsche Datumstexte, die der
  JavaScript-Date-Konstruktor nicht zuverlässig versteht.

  Wird von js/institutseite.js UND js/veroeffentlichungen-seite.js
  genutzt.
*/

const DATUM_MONATSNAMEN = [
  "Januar", "Februar", "März", "April", "Mai", "Juni",
  "Juli", "August", "September", "Oktober", "November", "Dezember"
];

function formatiereDatumDeutsch(isoDatum) {

  const teile = String(isoDatum).split("-");

  if (teile.length !== 3) {
    // Kein erkennbares ISO-Datum - unverändert zurückgeben, statt die
    // Seite deswegen kaputtgehen zu lassen.
    return isoDatum;
  }

  const [jahr, monat, tag] = teile;

  const monatsName = DATUM_MONATSNAMEN[Number(monat) - 1];

  if (!monatsName) {
    return isoDatum;
  }

  // Führende Null beim Tag entfernen (z.B. "05" -> "5").
  const tagOhneFuehrendeNull = String(Number(tag));

  return `${tagOhneFuehrendeNull}. ${monatsName} ${jahr}`;
}

/*
  Debug-Modus: zeigt auch Inhalte mit einem "erstellt"-/"datum"-Feld
  in der Zukunft an (noch unveröffentlichte Ratgeber, News, etc.).

  Aktivieren:   irgendeine Seite mit ?debug=1 aufrufen
  Deaktivieren: irgendeine Seite mit ?debug=0 aufrufen
  Der Zustand wird in localStorage gemerkt, gilt also seitenübergreifend,
  bis er wieder ausgeschaltet wird - praktisch beim lokalen Testen mit
  `python3 -m http.server`.
*/
function istLokaleEntwicklung() {

  const host = window.location.hostname;

  return (
    host === "localhost" ||
    host === "127.0.0.1" ||
    host === "[::1]" ||
    /^192\.168\./.test(host)   // Handy-Test im Heimnetz; bei Bedarf löschen
  );
}

function istDebugModusAktiv() {

  // Auf der veröffentlichten Seite gibt es keinen Debug-Modus.
  if (!istLokaleEntwicklung()) return false;

  const params = new URLSearchParams(window.location.search);

  if (params.has("debug")) {
    const aktiv = params.get("debug") !== "0" && params.get("debug") !== "false";
    try {
      localStorage.setItem("debugModus", aktiv ? "1" : "0");
    } catch (fehler) {
      // localStorage evtl. nicht verfügbar (z.B. privater Modus) -
      // dann gilt der Debug-Modus nur für diesen einen Seitenaufruf.
    }
    return aktiv;
  }

  try {
    return localStorage.getItem("debugModus") === "1";
  } catch (fehler) {
    return false;
  }
}

/*
  Prüft, ob ein ISO-Datum bereits erreicht ist (heute oder in der
  Vergangenheit liegt). Funktioniert zuverlässig, weil "datum" im
  ISO-Format vorliegt (new Date("2028-08-22") lässt sich überall
  gleich parsen und vergleichen - anders als deutsche Datumstexte).

  Wird von js/institutseite.js UND js/veroeffentlichungen-seite.js
  genutzt, um Veröffentlichungen mit einem Datum in der Zukunft
  auszublenden.

  Im Debug-Modus (siehe istDebugModusAktiv() oben) wird der Filter
  übersprungen - dann gilt jedes Datum als "erreicht".
*/
function istDatumErreicht(isoDatum) {
  if (istDebugModusAktiv()) {
    return true;
  }
  const heute = new Date();
  return new Date(isoDatum) <= heute;
}
/*
  Lädt und rendert die News-Beiträge aus newsListe.

  Die Markdown-Dateien liegen unter:

    md/news/

  Unterstützt werden alle Formatierungen, die
  parseMarkdownBloecke() aus markdown.js versteht,
  insbesondere:

  **fett**

  *kursiv*

  "datum" in newsListe (siehe js/news.js) liegt im ISO-Format
  (YYYY-MM-DD) vor und wird über formatiereDatumDeutsch() (siehe
  js/datumsformat.js) in die deutsche Lesefassung umgewandelt.
*/

const newsContainer = document.getElementById("news-liste");

// Anzahl der Absätze (Markdown-Blöcke), die standardmäßig sichtbar
// sind, bevor ein "Mehr"-Button den Rest einblendet.
const NEWS_TEASER_BLOECKE = 2;

// true: Link und Bild eines Beitrags werden - genau wie der restliche
// Text - erst beim Ausklappen sichtbar.
// false: Link und Bild sind immer sichtbar, unabhängig vom Ausklapp-
// Zustand des Textes.
const NEWS_LINK_UND_BILD_NUR_BEI_MEHR = true;

// true: der neueste Beitrag (der erste in newsListe, siehe js/news.js)
// ist von Anfang an komplett ausgeklappt, alle anderen eingeklappt.
// false: alle Beiträge starten eingeklappt.
const NEWS_ERSTEN_BEITRAG_AUSGEKLAPPT = true;

// Singular-Label je Kategorie, das auf der ungefilterten Seite
// (news.html, kein NEWS_SEITE_KATEGORIE gesetzt) rechts neben dem
// Datum angezeigt wird - siehe ladeNewsBeitrag() unten. Die Werte
// von NewsKategorie (js/news.js) selbst sind Plural, da sie auch als
// Überschriften/Filterwerte verwendet werden.
const NEWS_KATEGORIE_LABEL_SINGULAR = {
  [NewsKategorie.RATGEBER]: "Ratgeber",
  [NewsKategorie.FALLAKTEN]: "Fallakte",
  [NewsKategorie.PUBLIKATIONEN]: "Publikation",
  [NewsKategorie.INSTITUTSLEBEN]: "Institutsleben",
  [NewsKategorie.ALLTAGSSTUDIEN]: "Alltagsstudie",
  [NewsKategorie.PERSONAL]: "Personal des Monats",
};

let alleSichtbarenNews = [];
let aktuelleNewsKategorie = "Alle";

// Delegierter Klick-Handler für alle "Mehr"/"Weniger"-Buttons - EINMAL
// registriert, funktioniert aber auch für Buttons, die erst später
// (nach dem Laden der Beiträge) in den Container eingefügt werden.
//
// Ein Button kann mehrere Elemente gleichzeitig ein-/ausblenden (z.B.
// den restlichen Text UND den Link/Bild-Block) - dafür bekommen alle
// zusammengehörigen Elemente dasselbe data-mehr-gruppe="<index>" und
// werden hier gemeinsam umgeschaltet.
newsContainer.addEventListener("click", event => {

  const button = event.target.closest(".news-mehr-button");

  if (!button) {
    return;
  }

  const gruppe = button.dataset.group;

  const zielElemente = newsContainer.querySelectorAll(
    `[data-mehr-gruppe="${gruppe}"]`
  );

  if (zielElemente.length === 0) {
    return;
  }

  // Zustand am ersten Element der Gruppe ablesen - alle Elemente
  // derselben Gruppe sind immer synchron (hidden oder nicht).
  const istEingeklappt = zielElemente[0].hasAttribute("hidden");

  zielElemente.forEach(element => {
    if (istEingeklappt) {
      element.removeAttribute("hidden");
    } else {
      element.setAttribute("hidden", "");
    }
  });

  button.textContent = istEingeklappt ? "Weniger anzeigen" : "Mehr anzeigen";
});


/*
  Lightbox zum vergrößerten Anzeigen von News-Bildern - nutzt dasselbe
  Overlay (#foto-lightbox) und dieselbe Logik wie die Institutsleben-
  Galerie, siehe js/foto-lightbox.js.

  Das Overlay-Markup steht im HTML erst NACH diesem <script>-Tag -
  initialisiereFotoLightboxSchliessen() müsste es also zu früh suchen,
  wenn wir sie sofort aufrufen. Deshalb hier auf DOMContentLoaded
  warten (bzw. sofort ausführen, falls das Dokument - z.B. bei
  langsamem Skript-Download - ohnehin schon fertig geparst ist).
*/

if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    initialisiereFotoLightboxSchliessen
  );
} else {
  initialisiereFotoLightboxSchliessen();
}

// Delegierter Klick-Handler für alle News-Bilder - genau wie beim
// "Mehr"-Button funktioniert das auch für Bilder, die erst später
// (nach dem Laden der Beiträge) in den Container eingefügt werden.
newsContainer.addEventListener("click", event => {

  const bild = event.target.closest(".institutsfoto-klickbar");

  if (!bild) {
    return;
  }

  oeffneFotoLightbox(bild.dataset.bild, bild.dataset.titel);
});

// Bedienung auch per Tastatur (Enter/Leertaste), da die Bilder
// unten als fokussierbare, aber nicht-native Buttons markiert sind.
newsContainer.addEventListener("keydown", event => {

  if (event.key !== "Enter" && event.key !== " ") {
    return;
  }

  const bild = event.target.closest(".institutsfoto-klickbar");

  if (!bild) {
    return;
  }

  event.preventDefault();
  oeffneFotoLightbox(bild.dataset.bild, bild.dataset.titel);
});


async function ladeNews() {

  try {

    const alleNews = await ladeAlleNews();

    /*
      News einmalig vorbereiten:
      - Beiträge ohne erreichtes Datum entfernen
      - neueste Beiträge zuerst
    */

    alleSichtbarenNews = alleNews
      .filter(beitrag =>
        istDatumErreicht(beitrag.datum)
      )
      .sort(
        (a, b) =>
          new Date(b.datum) - new Date(a.datum)
      );

    /*
      Falls die Seite eine feste Kategorie hat
      (z.B. eine frühere Kategorie-Unterseite),
      diese als Anfangsfilter verwenden.
    */

    if (
      typeof NEWS_SEITE_KATEGORIE !== "undefined" &&
      NEWS_SEITE_KATEGORIE !== null
    ) {
      aktuelleNewsKategorie = NEWS_SEITE_KATEGORIE;
    }

    await rendereGefilterteNews();

  } catch (fehler) {

    console.error(
      "Fehler beim Laden der News:",
      fehler
    );

    newsContainer.innerHTML = `
      <section class="section">

        <div class="wrap">

          <p>
            <em>
              Die News konnten leider nicht geladen werden.
            </em>
          </p>

        </div>

      </section>
    `;
  }
}

async function rendereGefilterteNews() {

  const kategorieFilterAktiv =
    aktuelleNewsKategorie !== "Alle";

  const sichtbareNews =
    kategorieFilterAktiv

      ? alleSichtbarenNews.filter(
          beitrag =>
            beitrag.kategorie === aktuelleNewsKategorie
        )

      : alleSichtbarenNews;


  if (sichtbareNews.length === 0) {

    newsContainer.innerHTML = `
      <section class="section">

        <div class="wrap">

          <p>
            ${
              kategorieFilterAktiv
                ? "In dieser Kategorie gibt es derzeit keine Neuigkeiten."
                : "Derzeit gibt es keine Neuigkeiten."
            }
          </p>

        </div>

      </section>
    `;

    return;
  }


  const beitragHtml =
    await Promise.all(
      sichtbareNews.map(
        (beitrag, index) =>
          ladeNewsBeitrag(
            beitrag,
            index,
            !kategorieFilterAktiv
          )
      )
    );


  newsContainer.innerHTML =
    beitragHtml.join("\n");
}


function ladeNewsBeitrag(beitrag, index, zeigeKategorie) {

  const pfad =
    `md/news/${encodeURIComponent(beitrag.datei)}`;

  // Beiträge mit eigenem Feld "text" (z.B. Personal des Monats, siehe
  // js/news.js) brauchen keine Markdown-Datei unter md/news/.
  const markdownQuelle =
    beitrag.text !== undefined
      ? Promise.resolve(beitrag.text)
      : fetch(pfad)
          .then(antwort => {

            if (!antwort.ok) {
              throw new Error(
                `News-Datei nicht gefunden: ${beitrag.datei}`
              );
            }

            return antwort.text();
          });

  return markdownQuelle
    .then(markdown => {

      const bloecke =
        parseMarkdownBloecke(markdown);

      /*
        Nur die ersten NEWS_TEASER_BLOECKE Absätze standardmäßig
        zeigen. Der Rest landet in einem versteckten Container, der
        erst über den "Mehr"-Button (siehe Klick-Handler oben)
        eingeblendet wird - und nur dann, wenn es überhaupt mehr zu
        zeigen gibt.
      */

      const teaserBloecke =
        bloecke.slice(0, NEWS_TEASER_BLOECKE);

      const restBloecke =
        bloecke.slice(NEWS_TEASER_BLOECKE);

      const teaserHtml =
        teaserBloecke.join("\n");

      const hatZusaetzlichenText =
        restBloecke.length > 0;

      /*
        Der neueste Beitrag (index === 0) kann per
        NEWS_ERSTEN_BEITRAG_AUSGEKLAPPT von Anfang an komplett
        ausgeklappt starten - alle anderen starten eingeklappt.
      */

      const istInitialAusgeklappt =
        NEWS_ERSTEN_BEITRAG_AUSGEKLAPPT && index === 0;

      // Als Attribut-String für die Templates unten: "hidden" oder
      // "" (leer), je nachdem, ob dieser Beitrag initial eingeklappt
      // oder ausgeklappt sein soll.
      const hiddenAttribut =
        istInitialAusgeklappt ? "" : "hidden";

      /*
        Optionaler Link, z.B. zum neuen Ratgeber.
      */

      let linkHtml = "";

      if (beitrag.link) {

        linkHtml = `
          <p class="news-link-wrap">
            <a
              href="${beitrag.link}"
              class="news-link"
            >
              ${beitrag.linkText || "Mehr erfahren"} →
            </a>
          </p>
        `;
      }


      /*
        Optionales Bild.

        Das Bild steht bewusst GANZ AM ENDE
        des Beitrags.
      */

      let bildHtml = "";

      if (beitrag.bild) {

        bildHtml = `
          <img
            class="news-bild institutsfoto-klickbar"
            src="${beitrag.bild}"
            alt="${beitrag.titel}"
            data-bild="${beitrag.bild}"
            data-titel="${beitrag.titel}"
            loading="lazy"
            tabindex="0"
          >
        `;
      }

      const hatBild = Boolean(beitrag.bild);
      const hatLink = Boolean(beitrag.link);

      /*
        Kategorie-Label (Singular) rechts neben dem Datum - nur auf der
        ungefilterten Seite (news.html), siehe zeigeKategorie-Parameter
        oben. Auf Kategorie-Unterseiten wäre es redundant, da dort
        ohnehin nur eine einzige Kategorie gezeigt wird.
      */
      const kategorieLabelHtml =
        zeigeKategorie && beitrag.kategorie
          ? `<span class="news-kategorie-label">${NEWS_KATEGORIE_LABEL_SINGULAR[beitrag.kategorie] || beitrag.kategorie}</span>`
          : "";

      // Ein Bild rechtfertigt für sich allein schon einen
      // "Mehr"-Button - ein Link dagegen NICHT: ein Beitrag, der nur
      // wegen seines Links "unvollständig" wäre, zeigt den Link
      // stattdessen sofort an, ganz ohne Button und ohne ihn zu
      // verstecken (siehe hatMehrInhalt und linkUndBildVerstecken
      // unten).
      const bildRechtfertigtMehrButton =
        NEWS_LINK_UND_BILD_NUR_BEI_MEHR && hatBild;

      // Gibt es überhaupt etwas, das einen "Mehr"-Button rechtfertigt
      // (zusätzlicher Text ODER ein zu versteckendes Bild)?
      const hatMehrInhalt =
        hatZusaetzlichenText || bildRechtfertigtMehrButton;

      // Link und Bild werden nur dann versteckt, wenn es ohnehin
      // schon einen Button gibt (wegen Text oder Bild) - ein Beitrag,
      // der NUR wegen des Links "mehr" bräuchte, bleibt komplett
      // sichtbar, ohne Button.
      const linkUndBildVerstecken =
        NEWS_LINK_UND_BILD_NUR_BEI_MEHR &&
        hatMehrInhalt &&
        (hatLink || hatBild);

      /*
        Die Beiträge wechseln sich farblich ab.
        Der erste Beitrag verwendet .section,
        der zweite .section-alt, der dritte wieder
        .section usw.
      */

      const sectionKlasse =
        index % 2 === 0
          ? "section"
          : "section section-alt";

      /*
        Der ausklappbare Rest-Text wird ABSICHTLICH INNERHALB von
        .news-text verschachtelt (statt als Geschwister-Element
        danach): so bleibt die bestehende Regel
        ".news-text p:last-child { margin-bottom: 0; }" korrekt -
        sie entfernt dann weiterhin nur den Abstand nach dem
        WIRKLICH letzten Absatz des Beitrags, nicht mehr fälschlich
        nach dem letzten Teaser-Absatz.
      */

      let restTextHtml = "";

      if (hatZusaetzlichenText) {
        restTextHtml = `
          <div
            class="news-text-rest"
            data-mehr-gruppe="${index}"
            ${hiddenAttribut}
          >
            ${restBloecke.join("\n")}
          </div>
        `;
      }

      /*
        Link und Bild: je nach NEWS_LINK_UND_BILD_NUR_BEI_MEHR entweder
        immer sichtbar, oder in denselben versteckten Zustand versetzt
        wie der restliche Text (gehören dann zur selben
        data-mehr-gruppe und werden vom selben Button umgeschaltet).
      */

      const linkUndBildHtml = `${linkHtml}${bildHtml}`;

      const linkUndBildBereichHtml = linkUndBildVerstecken
        ? `
          <div
            class="news-link-bild-wrap"
            data-mehr-gruppe="${index}"
            ${hiddenAttribut}
          >
            ${linkUndBildHtml}
          </div>
        `
        : linkUndBildHtml;

      const mehrButtonHtml = hatMehrInhalt
        ? `
          <button
            type="button"
            class="news-mehr-button"
            data-group="${index}"
          >
            ${istInitialAusgeklappt ? "Weniger anzeigen" : "Mehr anzeigen"}
          </button>
        `
        : "";


      /*
        Reihenfolge von Button und Link/Bild-Bereich hängt von
        NEWS_LINK_UND_BILD_NUR_BEI_MEHR ab: sind Link und Bild Teil des
        versteckten Bereichs, soll der "Mehr"/"Weniger"-Button logisch
        danach kommen (also unter dem Bild), nicht davor.
      */

      return `
        <section class="news-beitrag ${sectionKlasse}">

          <div class="wrap">

            <div class="news-meta">
              ${beitrag.datum ? formatiereDatumDeutsch(beitrag.datum) : ""}
              ${kategorieLabelHtml ? ` · ${kategorieLabelHtml}` : ""}
            </div>

            <h2 class="news-titel">
              ${beitrag.titel}
            </h2>

            <div class="news-text">
              ${teaserHtml}
              ${restTextHtml}
            </div>

            ${NEWS_LINK_UND_BILD_NUR_BEI_MEHR
              ? `${linkUndBildBereichHtml}\n${mehrButtonHtml}`
              : `${mehrButtonHtml}\n${linkUndBildBereichHtml}`}

          </div>

        </section>
      `;
    });
}

function baueAktuellesFilter() {

  const section =
    document.getElementById("aktuelles-filter");

  const container =
    document.getElementById("aktuelles-filter-container");

  if (!section || !container) return;

  const kategorien = [
    NewsKategorie.RATGEBER,
    NewsKategorie.FALLAKTEN,
    NewsKategorie.ALLTAGSSTUDIEN,
    NewsKategorie.PUBLIKATIONEN,
    NewsKategorie.INSTITUTSLEBEN,
    NewsKategorie.PERSONAL
  ];
  const filter = [
    "Alle",
    ...kategorien
  ];

  container.innerHTML = `

    <p class="aktuelles-filter-label">
      Nach Kategorie filtern
    </p>

    <div class="aktuelles-filter-liste">

      ${filter.map(
        eintrag => `

          <button
            type="button"
            class="aktuelles-filter-button${eintrag === "Alle" ? " aktiv" : ""}"
            data-kategorie="${eintrag}">

            <span>${eintrag}</span>

          </button>

        `
      ).join("")}

    </div>

  `;

  container
    .querySelectorAll(".aktuelles-filter-button")
    .forEach(button => {

      button.addEventListener("click", () => {

        const kategorie =
          button.dataset.kategorie;

        container
          .querySelectorAll(".aktuelles-filter-button")
          .forEach(b =>
            b.classList.remove("aktiv")
          );

        button.classList.add("aktiv");

        filtereAktuelles(kategorie);

      });

    });
}

function filtereAktuelles(kategorie) {
  aktuelleNewsKategorie = kategorie;
  rendereGefilterteNews();
}

ladeNews();
baueAktuellesFilter();
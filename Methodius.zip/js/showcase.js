/*
  Zeigt einen großen Einzel-Ratgeber auf der Startseite, ausgehend vom
  aktuellsten, mit Pfeilen zum Durchklicken durch die Chronologie.
  Setzt voraus, dass js/ratgeber.js (ratgeberListe) vor diesem Skript
  eingebunden ist.
*/

(function () {
  const showcase = document.getElementById("ratgeber-showcase");
  const cover = document.getElementById("showcase-cover");
  const link = document.getElementById("showcase-link");
  const prevBtn = document.getElementById("showcase-prev");
  const nextBtn = document.getElementById("showcase-next");

  if (!cover) return;

  // Keine Ratgeberliste vorhanden.
  if (typeof ratgeberListe === "undefined" || ratgeberListe.length === 0) {
    if (showcase) showcase.style.display = "none";
    return;
  }

  // Nur Ratgeber anzeigen, die ein "erstellt"-Datum haben UND dessen
  // Datum bereits erreicht ist (heute oder in der Vergangenheit) -
  // siehe istDatumErreicht() in js/datumsformat.js. Ratgeber ohne
  // Datum oder mit einem Datum in der Zukunft werden im Showcase
  // ausgeblendet.
  const sichtbareRatgeberAlle = ratgeberListe.filter(
    buch => istDatumErreicht(buch.erstellt)
  );

  // Keine sichtbaren Ratgeber übrig.
  if (sichtbareRatgeberAlle.length === 0) {
    if (showcase) showcase.style.display = "none";
    return;
  }

  // Chronologie, neuestes zuerst: Laut ratgeber.js werden neue Bücher
  // am ENDE der Liste ergänzt ("Neueste Ratgeber" zeigt die letzten
  // Einträge) - die Liste wird also einfach umgedreht.
  const chronologie = [...sichtbareRatgeberAlle].reverse();

  let index = 0; // 0 = aktuellster Ratgeber

  function zeigeAktuellen() {
    const buch = chronologie[index];
    const pfad = encodeURIComponent(buch.slug);

    cover.src = `pics/ratgeber-mockup/${pfad}.png`;
    cover.alt = `Cover: ${buch.titel}`;
    link.href = `ratgeber-${buch.urlSlug}.html`;

    prevBtn.disabled = index <= 0;
    nextBtn.disabled = index >= chronologie.length - 1;
  }

  prevBtn.addEventListener("click", () => {
    if (index > 0) {
      index--;
      zeigeAktuellen();
    }
  });

  nextBtn.addEventListener("click", () => {
    if (index < chronologie.length - 1) {
      index++;
      zeigeAktuellen();
    }
  });

  zeigeAktuellen();
})();
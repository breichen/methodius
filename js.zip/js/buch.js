/*
  Liest den Slug aus der URL (?titel=...), sucht das passende Buch
  in ratgeberListe (aus js/ratgeber.js) und zeigt Bild + Text an.
*/

const container = document.getElementById("buch-inhalt");

// Baut die optionale "Vorgeschlagen von: ..." / "Veröffentlicht: ..." /
// "Aktualisiert: ..."-Zeile aus den Feldern "einsender", "erstellt" und
// "aktualisiert" in ratgeber.js. "erstellt" und "aktualisiert" werden im
// ISO-Format (YYYY-MM-DD) erwartet und für die Anzeige über
// formatiereDatumDeutsch() (siehe js/datumsformat.js) in die deutsche
// Lesefassung umgewandelt - "einsender" ist dagegen kein Datum und
// bleibt unverändert. Alle drei Angaben sind optional - fehlt eine,
// wird die entsprechende Zeile einfach weggelassen. Ist "einsender"
// gesetzt, erscheint "Vorgeschlagen von: ..." ganz oben, noch vor
// "Veröffentlicht: ...". Sind alle drei leer, liefert die Funktion "".
function baueDatumsHinweis(buch) {
  const zeilen = [];

  // Bandnummer anhand der Reihenfolge in ratgeberListe bestimmen
  const bandnummer = ratgeberListe.findIndex(r => r.slug === buch.slug) + 1;

  if (bandnummer > 0) {
    zeilen.push(`<p class="buch-datum">BAND ${bandnummer}</p>`);
  }

  if (buch.kategorie) {
    const slug = RatgeberKategorieInfo[buch.kategorie]?.slug;
    const kategorieHtml = slug
      ? `<a href="alle-ratgeber.html?kategorie=${slug}">${buch.kategorie}</a>`
      : buch.kategorie;
    zeilen.push(`<p class="buch-datum">Kategorie: ${kategorieHtml}</p>`);
  }

  if (buch.einsender) {
    zeilen.push(`<p class="buch-datum">Vorgeschlagen von: ${buch.einsender}</p>`);
  }

  if (buch.erstellt) {
    zeilen.push(`<p class="buch-datum">Veröffentlicht: ${formatiereDatumDeutsch(buch.erstellt)}</p>`);
  }

  if (buch.aktualisiert) {
    zeilen.push(`<p class="buch-datum">Aktualisiert: ${formatiereDatumDeutsch(buch.aktualisiert)}</p>`);
  }

  return zeilen.length
    ? `<div class="buch-datums-hinweis">${zeilen.join("\n")}</div>`
    : "";
}

// URL-Parameter auslesen, z.B. "der-perfekte-sonntag" aus buch.html?titel=der-perfekte-sonntag
const parameter = new URLSearchParams(window.location.search);
const slug = parameter.get("titel");
const buch = ratgeberListe.find(b => b.slug === slug);

if (!buch) {
  // Falscher oder fehlender Link -> freundliche Fehlermeldung statt kaputter Seite
  container.innerHTML = `
    <section class="section">
      <div class="wrap">
        <h1>Ratgeber nicht gefunden</h1>
        <p>Diesen Ratgeber gibt es (noch) nicht. <a href="index.html#ratgeber">Zur Übersicht</a>.</p>
      </div>
    </section>
  `;
} else {
  document.title = buch.titel + " – Dr. Maximilian Methodius";

  // Auch hier: encodeURIComponent macht den Dateinamen URL-sicher
  // (wichtig bei Leerzeichen, Kommas, Klammern im Titel).
  const pfad = encodeURIComponent(buch.slug);
  const frontCoverPfad = `pics/ratgeber-front/${pfad}.png`;
  const backCoverPfad  = `pics/ratgeber-back/${pfad}.png`;

  // "Vorgeschlagen von: ..." / "Veröffentlicht: ..." / "Aktualisiert: ..."
  // nur anzeigen, wenn die jeweilige Angabe in ratgeber.js gesetzt wurde -
  // alle drei sind komplett optional.
  const datumsHtml = baueDatumsHinweis(buch);

  // Bild sofort anzeigen, Text kommt gleich per fetch() nach
  //
  // Alles hier liegt bewusst innerhalb von .wrap, damit z.B. der
  // Datums-Hinweis (.buch-datum) dieselbe Breite/Einrückung wie der
  // Rest der Seite bekommt - ohne eigene Zentrierungs-Regel würde er
  // sonst ganz links kleben (anders als z.B. .book-cover oder
  // .blaettern-wrap, die beide ihre eigene Breitenbegrenzung haben).
  // Die später in #buch-text eingefügten Kapitel-Sections brechen
  // trotz dieser zusätzlichen Verschachtelung weiterhin korrekt auf
  // volle Breite aus (siehe FULL_BLEED_STYLE unten), da dieser Trick
  // auf "100vw" (Viewport-Breite) basiert und nicht auf der Breite
  // des jeweiligen Elternelements.
  container.innerHTML = `
    <section class="section">
      <div class="wrap">
        ${datumsHtml}
        <div class="book-cover-duo">
          <img
            class="book-cover-duo-bild"
            id="buch-cover-front"
            src="${frontCoverPfad}"
            alt="Frontcover: ${buch.titel}"
            style="cursor: zoom-in;"
          >
          <img
            class="book-cover-duo-bild"
            id="buch-cover-back"
            src="${backCoverPfad}"
            alt="Rückcover: ${buch.titel}"
            style="cursor: zoom-in;"
          >
        </div>
        <p class="blaettern-wrap">
          <a href="#ratgeber-kommentare" id="kommentar-link" class="kommentar-link">
            💬 <span id="kommentar-link-text">Kommentare</span>
          </a>

          <a href="#" id="blaettern-link" class="blaettern-link">
            📖 Blättern
          </a>

          <button type="button" id="teilen-button" class="teilen-button">
            🔗 Teilen
          </button>
        </p>

        <div id="buch-text">
          <p>Lade Text …</p>
        </div>
      </div>
    </section>
  `;

  // Klick auf das Cover -> Bild vergrößert in einer Lightbox anzeigen
  initCoverLightbox("buch-cover-front");
  initCoverLightbox("buch-cover-back");

  // Teilen-Button (siehe js/teilen.js) - teilt Cover-Bild + Titel + Link
  initTeilenButtonRatgeber(document.getElementById("teilen-button"), {
    titel: buch.titel,
    bildUrl: frontCoverPfad
  });

  // Der Link wird erst sichtbar/klickbar, wenn der Text geladen ist
  const blaetternLink = document.getElementById("blaettern-link");
  blaetternLink.style.visibility = "hidden";

  fetch(`md/ratgeber/${pfad}.md`)
    .then(antwort => {
      if (!antwort.ok) throw new Error("Datei nicht gefunden");
      return antwort.text();
    })
    .then(markdown => {

      const { fliesstextBloecke, flipbookBloecke, quiz } =
        verarbeiteRatgeberMarkdown(markdown);

      document.getElementById("buch-text").innerHTML =
        baueKapitelSections(fliesstextBloecke);

      initFlipbook(flipbookBloecke);
      initQuizButton(quiz);

      ladeKommentare({
        slug: buch.slug,
        ordner: "ratgeber-kommentare",
        containerId: "buch-text",
        sectionId: "ratgeber-kommentare"
      });

      blaetternLink.style.visibility = "visible";
    })
    .catch(() => {
      document.getElementById("buch-text").innerHTML = `
        <p><em>Der Text zu diesem Ratgeber konnte nicht geladen werden.
        Läuft die Seite über einen lokalen Server (nicht per Doppelklick geöffnet)?</em></p>
      `;
    });
}

/* ============================================
   TABELLEN
   Erkennt Markdown-Tabellen (Pipe-Syntax mit |---|-Trennzeile),
   wandelt sie VOR dem eigentlichen Markdown-Parsing in echtes
   HTML um und setzt sie per Platzhalter wieder in die fertigen
   Blöcke ein - so bleibt parseMarkdownBloecke() unangetastet.
   ============================================ */

// Zerlegt eine Tabellenzeile ("| A | B |") in ihre Zellen (["A", "B"]).
function zerlegeTabellenZeile(zeile) {
  let z = zeile.trim();
  if (z.startsWith("|")) z = z.slice(1);
  if (z.endsWith("|")) z = z.slice(0, -1);
  return z.split("|").map(zelle => zelle.trim());
}

// Prüft, ob eine Zeile die Trennzeile einer Tabelle ist (z.B. "|---|---|").
function istTabellenTrennzeile(zeile) {
  const zellen = zerlegeTabellenZeile(zeile);
  return (
    zellen.length > 0 &&
    zellen.every(zelle => /^:?-{2,}:?$/.test(zelle))
  );
}

// Durchsucht das rohe Markdown zeilenweise nach Tabellen, ersetzt jede
// gefundene Tabelle durch einen eindeutigen Platzhalter (eigener Absatz)
// und liefert zusätzlich das fertige HTML pro Tabelle zurück.
function extrahiereTabellenAusMarkdown(markdown) {
  const zeilen = markdown.split("\n");
  const ergebnisZeilen = [];
  const tabellenHtml = [];
  let i = 0;

  while (i < zeilen.length) {
    const koennteTabelleSein =
      zeilen[i].trim().startsWith("|") &&
      i + 1 < zeilen.length &&
      istTabellenTrennzeile(zeilen[i + 1]);

    if (koennteTabelleSein) {
      const kopfZellen = zerlegeTabellenZeile(zeilen[i]);
      i += 2; // Kopfzeile + Trennzeile überspringen

      const datenZeilen = [];
      while (i < zeilen.length && zeilen[i].trim().startsWith("|")) {
        datenZeilen.push(zerlegeTabellenZeile(zeilen[i]));
        i++;
      }

      const theadHtml = `<tr>${kopfZellen
        .map(zelle => `<th>${zelle}</th>`)
        .join("")}</tr>`;

      const tbodyHtml = datenZeilen
        .map(
          zellen =>
            `<tr>${zellen.map(zelle => `<td>${zelle}</td>`).join("")}</tr>`
        )
        .join("");

      const tabelleIndex = tabellenHtml.length;
      tabellenHtml.push(
        `<table class="ratgeber-tabelle"><thead>${theadHtml}</thead><tbody>${tbodyHtml}</tbody></table>`
      );

      // Leerzeilen drumherum sorgen dafür, dass der Platzhalter als
      // eigener Block erkannt wird (wie ein normaler Absatz).
      ergebnisZeilen.push("", `TABELLE_PLATZHALTER_${tabelleIndex}`, "");
    } else {
      ergebnisZeilen.push(zeilen[i]);
      i++;
    }
  }

  return { markdown: ergebnisZeilen.join("\n"), tabellenHtml };
}

// Ersetzt in den fertig geparsten Blöcken jeden Platzhalter-Block
// durch das zugehörige, bereits fertige Tabellen-HTML.
function setzeTabellenEin(bloecke, tabellenHtml) {
  return bloecke.map(block => {
    const match = block.match(/TABELLE_PLATZHALTER_(\d+)/);
    return match ? tabellenHtml[Number(match[1])] : block;
  });
}

/* ============================================
   MARKDOWN-ÜBERSETZUNG
   Die eigentliche Übersetzung (Überschriften, **fett**, *kursiv*,
   > Zitate, - Listen, --- als Trennlinie) übernimmt parseMarkdownBloecke()
   aus js/markdown.js. Hier kommt nur noch die Kapitel-, Autor- und
   Bonus-Quiz-spezifische Nachbearbeitung dazu, die NUR für
   Ratgeber-Seiten gilt.
   ============================================ */

// Übernimmt den kompletten Weg von rohem Markdown bis zu den fertigen
// HTML-Blöcken UND liefert zusätzlich die extrahierten Quiz-Daten
// (falls ein BONUS-Abschnitt gefunden wurde).
//
// Liefert ZWEI verschiedene Block-Arrays:
// - fliesstextBloecke: BONUS-Abschnitt durch einen Button ersetzt
//   (öffnet das interaktive Quiz-Overlay)
// - flipbookBloecke: unverändert, BONUS-Abschnitt bleibt als normaler
//   Text stehen - in einem physischen Buch kann man schließlich nicht
//   klicken, daher zeigt die Blätter-Ansicht das Quiz statisch an.
// Nummeriert die Bonus-Quiz-Fragen im Flipbook mit demselben Badge wie
// im Quiz-Dialog und im PDF, statt der rohen Markdown-Nummerierung
// ("1. Frage-Text"). Wirkt NUR innerhalb des BONUS-Abschnitts (von der
// "BONUS:"-Überschrift bis zur nächsten <h1> bzw. bis zum Ende), damit
// normale, nicht zum Quiz gehörende "1. ..."-Absätze unangetastet
// bleiben.
function nummeriereQuizFragenImFlipbook(bloecke) {
  // WICHTIG: An dieser Stelle im Ablauf hat bereinigeKapitelUeberschriften()
  // bereits gelaufen, das JEDE Überschrift außer der allerersten im ganzen
  // Buch zu <h2> macht - die "BONUS:"-Überschrift ist an dieser Stelle also
  // schon ein <h2>, kein <h1> mehr. Deshalb hier nach beidem suchen.
  const headingIndizes = bloecke.reduce((acc, block, i) => {
    if (block.startsWith("<h1") || block.startsWith("<h2")) acc.push(i);
    return acc;
  }, []);

  const bonusStart = headingIndizes.find(i => {
    const text = bloecke[i].replace(/^<h[12]>|<\/h[12]>$/g, "");
    return text.startsWith("BONUS:");
  });

  if (bonusStart === undefined) {
    return bloecke;
  }

  const naechsteHeading = headingIndizes.find(i => i > bonusStart);
  const bonusEnde = naechsteHeading !== undefined ? naechsteHeading : bloecke.length;

  return bloecke.map((block, i) => {
    if (i <= bonusStart || i >= bonusEnde) return block;

    const match = block.match(/^<p><strong>(\d+)\.\s*(.+?)<\/strong><\/p>$/);
    if (!match) return block;

    return `<p class="quiz-frage-flipbook"><strong><span class="quiz-nummer">${match[1]}</span>${match[2]}</strong></p>`;
  });
}

function verarbeiteRatgeberMarkdown(markdown) {
  // NEU: Tabellen zuerst herausziehen, damit parseMarkdownBloecke()
  // die Pipe-Syntax nicht falsch interpretiert.
  const { markdown: markdownOhneTabellen, tabellenHtml } =
    extrahiereTabellenAusMarkdown(markdown);

  const rohMitPlatzhaltern = parseMarkdownBloecke(markdownOhneTabellen);
  const roh = setzeTabellenEin(rohMitPlatzhaltern, tabellenHtml);

  // ... ab hier bleibt alles wie bisher ...
  const flipbookBloecke = nummeriereQuizFragenImFlipbook(
    styleAutorErwaehnung(
      entferneUntertitelAlsH2(bereinigeKapitelUeberschriften(roh))
    )
  );

  const { bloecke: ohneBonus, quiz } = extrahiereBonusQuiz(roh);
  const fliesstextBloecke = styleAutorErwaehnung(
    entferneUntertitelAlsH2(bereinigeKapitelUeberschriften(ohneBonus))
  );

  return { fliesstextBloecke, flipbookBloecke, quiz };
}

// Nur die Fließtext-Blöcke, ohne Quiz-Daten - falls an anderer Stelle
// mal nur der Text gebraucht wird.
function markdownZuBloecke(markdown) {
  return verarbeiteRatgeberMarkdown(markdown).fliesstextBloecke;
}

// Text, der als handschriftliche Unterschrift über der Namenszeile im
// letzten Kapitel erscheint - frei erfunden, wie ein Brief-Abschluss.
const AUTOR_SIGNATUR_TEXT = "Maximilian Methodius";

// Findet die Namenszeile "Dr. Maximilian Methodius" im ERSTEN Kapitel und
// gestaltet sie zu einem Vorstellungs-Block um (Einleitungstext in einem
// farbigen Kasten, darunter rundes Porträt + stilisierter Name). Findet
// dieselbe Namenszeile im LETZTEN Kapitel und setzt eine erfundene,
// handschriftliche Unterschrift direkt darüber.
function styleAutorErwaehnung(bloecke) {

  const NAME_REGEX = /<strong>Dr\. Maximilian Methodius<\/strong>/;

  const kapitelStarts = bloecke.reduce((acc, block, i) => {
    if (block.startsWith("<h1") || block.startsWith("<h2")) acc.push(i);
    return acc;
  }, []);

  if (kapitelStarts.length === 0) return bloecke;

  const namensIndizes = bloecke.reduce((acc, block, i) => {
    if (NAME_REGEX.test(block)) acc.push(i);
    return acc;
  }, []);

  if (namensIndizes.length === 0) return bloecke;

  const ersterKapitelStart = kapitelStarts[0];
  const letzterKapitelStart = kapitelStarts[kapitelStarts.length - 1];

  const vorstellungIndex = namensIndizes.find(
    i => i > ersterKapitelStart
  );

  const signaturIndex = [...namensIndizes]
    .reverse()
    .find(i => i > letzterKapitelStart);

  const ergebnis = [...bloecke];

  /* ==========================================
     ABSCHLUSS IM LETZTEN KAPITEL
     ========================================== */

  if (signaturIndex !== undefined) {

    const letzterBlockIndex = ergebnis.length - 1;

    const autorBeschreibung =
      ergebnis[letzterBlockIndex]
        .replace(/^\<p>/, "")
        .replace(/<\/p>$/, "")
        .replace(/^\<em>/, "")
        .replace(/<\/em>$/, "")
        .replace(/Autor, Satiriker/g, "Forscher, Autor");

    const autorName = ergebnis[signaturIndex]
      .replace(/^\<p>|<\/p>$/g, "");

    ergebnis[signaturIndex] = `
      <div class="autor-abschluss">
        <p class="autor-signatur">${AUTOR_SIGNATUR_TEXT}</p>
        <p class="autor-name">${autorName}</p>
        <p class="autor-abschluss-text">${autorBeschreibung}</p>
      </div>
    `;

    if (letzterBlockIndex !== signaturIndex) {
      ergebnis.splice(letzterBlockIndex, 1);
    }
  }

  /* ==========================================
     VORSTELLUNG IM ERSTEN KAPITEL
     ========================================== */

  if (
    vorstellungIndex !== undefined &&
    vorstellungIndex !== signaturIndex
  ) {

    const einleitungsBloecke = ergebnis.slice(
      ersterKapitelStart + 1,
      vorstellungIndex
    );

    const einleitungsHtml = einleitungsBloecke.length
      ? `<div class="autor-einleitung">${einleitungsBloecke.join("\n")}</div>`
      : "";

    const nameOhneTags = ergebnis[vorstellungIndex]
      .replace(/^\<p>|<\/p>$/g, "");

    const nameBox = `
      <div class="autor-box">
        <img
          class="autor-foto"
          src="pics/team/Methodius-nah.png"
          alt="Porträt von Dr. Maximilian Methodius"
        >
        <div>
          <p class="autor-kicker">Autor</p>
          <p class="autor-name">${nameOhneTags}</p>
          <p class="autor-tagline">
            Experte in allen Gebieten, Spezialist für ungewöhnliche
            Lösungen und anerkannter Fachmann für die großen und kleinen
            Probleme des modernen Lebens.
          </p>
        </div>
      </div>
    `;

    const neueBloecke = [
      ergebnis[ersterKapitelStart],
      ...(einleitungsHtml ? [einleitungsHtml] : []),
      nameBox
    ];

    ergebnis.splice(
      ersterKapitelStart,
      vorstellungIndex - ersterKapitelStart + 1,
      ...neueBloecke
    );
  }

  return ergebnis;
}


// Vereinheitlicht alle Kapitelüberschriften auf H2 - unabhängig davon,
// ob ein Kapitel mit einer generischen "Kapitel ..."/"Schlusswort"-
// Überschrift beginnt oder direkt mit seinem eigenen Titel. NUR die
// allererste Überschrift im Buch (der Buchtitel) bleibt eine H1.
//
// - "Kapitel ..."/"Schlusswort": die generische Überschrift wird
//   verworfen, alles bis zur nächsten Überschrift bleibt unverändert
//   stehen, und die darauf folgende H2 (der eigentliche Titel) wird
//   zur neuen Kapitelüberschrift - als H2 (bzw. als H1, falls es sich
//   um die allererste Überschrift des Buches handelt).
// - Eigener Titel MIT einer H2 darunter (bevor das nächste Kapitel
//   beginnt): beide Überschriften werden zu einer einzigen Überschrift
//   kombiniert, damit nicht zwei Überschriften auf gleicher Ebene
//   direkt aufeinanderfolgen. AUSNAHME: bei der allerersten Überschrift
//   wird NICHT kombiniert - die H1 bleibt eigenständig, und die
//   darauffolgende H2 bleibt unverändert eine eigene H2.
// - Eigener Titel OHNE H2 darunter: einfach übernommen (bzw. zu H2
//   herabgestuft, außer bei der allerersten Überschrift).
function bereinigeKapitelUeberschriften(bloecke) {
  const ergebnis = [];
  let i = 0;
  let istErsteUeberschrift = true;

  while (i < bloecke.length) {
    const block = bloecke[i];

    if (block.startsWith("<h1>")) {
      const istGenerischeUeberschrift = /^<h1>(Kapitel|Schlusswort)/.test(block);
      const eigenerTitel = block.slice(4, -5);

      // Nur die allererste Überschrift im ganzen Buch bleibt eine H1 -
      // alle weiteren Kapitelüberschriften werden zu H2.
      const warErsteUeberschrift = istErsteUeberschrift;
      const zielTag = warErsteUeberschrift ? "h1" : "h2";
      istErsteUeberschrift = false;

      i++;

      // Alles bis zur nächsten Überschrift (egal ob H1 oder H2)
      // sammeln, ohne dabei versehentlich in ein späteres Kapitel
      // hineinzulaufen.
      const zwischenBloecke = [];
      while (
        i < bloecke.length &&
        !bloecke[i].startsWith("<h1>") &&
        !bloecke[i].startsWith("<h2>")
      ) {
        zwischenBloecke.push(bloecke[i]);
        i++;
      }

      const naechsteIstH2 =
        i < bloecke.length && bloecke[i].startsWith("<h2>");

      if (istGenerischeUeberschrift) {
        // Wie bisher: generische Überschrift verwerfen, Zwischenblöcke
        // unverändert übernehmen, gefundene H2 wird zur neuen
        // Kapitelüberschrift (als H2, bzw. H1 bei der allerersten).
        ergebnis.push(...zwischenBloecke);

        if (naechsteIstH2) {
          const inhalt = bloecke[i].slice(4, -5);
          ergebnis.push(`<${zielTag}>${inhalt}</${zielTag}>`);
          i++;
        }
      } else if (naechsteIstH2 && warErsteUeberschrift) {
        // Allererste Überschrift: NICHT mit der H2 kombinieren - die H1
        // bleibt eigenständig stehen, und die H2 bleibt unverändert
        // eine eigene H2.
        ergebnis.push(`<h1>${eigenerTitel}</h1>`);
        ergebnis.push(...zwischenBloecke);
        ergebnis.push(bloecke[i]);
        i++;
      } else if (naechsteIstH2) {
        // Eigener Titel UND eine H2 im selben Kapitel -> zu einer
        // einzigen Überschrift kombinieren, die Kapitelüberschrift
        // bleibt aber am ursprünglichen Anfang des Kapitels stehen.
        const unterTitel = bloecke[i].slice(4, -5);
        ergebnis.push(`<h2>${eigenerTitel}: ${unterTitel}</h2>`);
        ergebnis.push(...zwischenBloecke);
        i++;
      } else {
        // Eigener Titel ohne H2 darunter -> übernehmen (bzw. zu H2
        // herabstufen, außer bei der allerersten Überschrift).
        ergebnis.push(`<${zielTag}>${eigenerTitel}</${zielTag}>`);
        ergebnis.push(...zwischenBloecke);
      }
    } else {
      ergebnis.push(block);
      i++;
    }
  }

  return ergebnis;
}

// Der Untertitel direkt unter dem Buchtitel ("Der ultimative Ratgeber für
// alle, die ...") ist im Markdown die H2 direkt nach der H1 und wird von
// bereinigeKapitelUeberschriften() bewusst NICHT mit der H1 kombiniert
// (siehe dortige Ausnahme für die allererste Überschrift) - er bleibt eine
// eigene H2. Inhaltlich ist er aber kein Kapitel und soll deshalb weder den
// Kapitel-Strich (.flipbook-page h2::after) bekommen noch als eigener
// Kapitel-/Seitenbeginn zählen (weder in baueKapitelSections() noch in der
// Flipbook-Paginierung, die beide anhand von "<h1"/"<h2" prüfen). Deshalb
// wird er hier - VOR all diesen Prüfungen - in ein reines <p> umgewandelt.
// Das ist die erste H2 im ganzen Buch, es gibt also immer höchstens eine
// Umwandlung pro Ratgeber.
function entferneUntertitelAlsH2(bloecke) {
  const index = bloecke.findIndex(block => block.startsWith("<h2>"));

  if (index === -1) return bloecke;

  const inhalt = bloecke[index].slice(4, -5);
  const ergebnis = [...bloecke];
  ergebnis[index] = `<p class="seite1-untertitel">${inhalt}</p>`;
  return ergebnis;
}

function markdownZuHtml(markdown) {
  return markdownZuBloecke(markdown).join("\n");
}


// NUR für die Fließtext-Ansicht: verpackt jedes Kapitel abwechselnd in
// class="section" bzw. class="section section-alt" (wie auf den
// anderen Seiten der Website), damit sich die Kapitel farblich
// voneinander absetzen. Ein neues Kapitel beginnt bei jeder Kapitel-
// überschrift (H1 - nur die allererste - oder H2) sowie beim
// Quiz-Start-Button (der Endteil ab dem Bonus-Quiz bekommt so
// ebenfalls einen eigenen, neuen Farbabschnitt). Die Blätter-Ansicht
// (Flipbook) bekommt bewusst KEINE Sections - dort blättert man ja
// ohnehin Seite für Seite, unabhängig von Kapitelgrenzen.
function baueKapitelSections(bloecke) {
  // "---" zwischen Kapiteln wird nicht gebraucht: Der Section-Wechsel
  // (mit eigenem Hintergrund) markiert den Kapitelübergang bereits
  // deutlich genug.
  const bloeckeOhneTrennlinie = bloecke.filter(block => block !== "<hr>");

  const kapitel = [];
  let aktuellesKapitel = null;

  bloeckeOhneTrennlinie.forEach(block => {
    const istKapitelStart =
      block.startsWith("<h1") ||
      block.startsWith("<h2") ||
      block.startsWith('<div class="quiz-start-wrap"');

    if (istKapitelStart || aktuellesKapitel === null) {
      aktuellesKapitel = [];
      kapitel.push(aktuellesKapitel);
    }

    aktuellesKapitel.push(block);
  });

  // Die Sections liegen innerhalb von #buch-inhalt/.wrap und wären
  // dadurch normalerweise auf dessen Breite beschränkt. Der Full-Bleed-
  // Trick (position:relative + left:50% + negative Margin) lässt den
  // Hintergrund trotzdem bis zum Seitenrand reichen, während der
  // innere .wrap-Container den Text weiterhin schön schmal hält.
  const FULL_BLEED_STYLE =
    "position:relative;left:50%;right:50%;width:100vw;margin-left:-50vw;margin-right:-50vw;";

  return kapitel
    .map((kapitelBloecke, index) => {
      const klasse = index % 2 === 0 ? "section" : "section section-alt";
      return `<section class="${klasse}" style="${FULL_BLEED_STYLE}"><div class="wrap">${kapitelBloecke.join("\n")}</div></section>`;
    })
    .join("\n");
}

/* ============================================
   BONUS-QUIZ
   Erkennt einen Top-Level-Abschnitt, dessen Überschrift mit "BONUS"
   beginnt (z.B. "# BONUS: Der Muskelabbau-Test"), zieht ihn aus dem
   normalen Textfluss heraus und ersetzt ihn durch einen Button. Der
   Button öffnet später ein Quiz-Overlay (siehe initQuizButton unten).
   ============================================ */

// Sucht die erste <h1>-Überschrift, die mit "BONUS" beginnt, schneidet
// den kompletten Abschnitt bis zur nächsten <h1> (oder Textende) heraus
// und ersetzt ihn im Block-Array durch einen einzelnen Button-Block.
function extrahiereBonusQuiz(bloecke) {
  const NAME_REGEX = /<strong>Dr\. Maximilian Methodius<\/strong>/;

  const h1Indizes = bloecke.reduce((acc, block, i) => {
    if (block.startsWith("<h1")) acc.push(i);
    return acc;
  }, []);

  const bonusStart = h1Indizes.find(i => {
    const text = bloecke[i].replace(/^<h1>|<\/h1>$/g, "");
    return text.startsWith("BONUS:");
  });

  if (bonusStart === undefined) {
    return { bloecke, quiz: null };
  }

  const naechsteH1 = h1Indizes.find(i => i > bonusStart);

  // WICHTIG: Die Namenszeile "Dr. Maximilian Methodius" (Unterschrift +
  // Name am Buchende) darf NIEMALS Teil des herausgeschnittenen
  // Bonus-Bereichs werden - egal ob sie im Markdown vor dem BONUS-
  // Abschnitt steht (dann betrifft es diese Prüfung ohnehin nicht) oder
  // direkt danach, ohne eigene Zwischenüberschrift. Sie bleibt also in
  // jedem Fall auf der eigentlichen Buch-Seite stehen.
  const namensIndexNachBonus = bloecke.findIndex(
    (block, i) => i > bonusStart && NAME_REGEX.test(block)
  );

  const grenzen = [naechsteH1, namensIndexNachBonus === -1 ? undefined : namensIndexNachBonus]
    .filter(i => i !== undefined);

  const bonusEnde = grenzen.length > 0 ? Math.min(...grenzen) : bloecke.length;

  const bonusBloecke = bloecke.slice(bonusStart, bonusEnde);
  const { titel, beschreibung, fragen, verbrauchteAnzahl } = parseQuizAusBloecken(bonusBloecke);
  const quiz = { titel, beschreibung, fragen };

  // Alles nach der letzten Frage (z.B. "Herzlichen Glückwunsch...")
  // bleibt als ganz normaler Text auf der Buch-Seite stehen, statt im
  // Quiz zu verschwinden - die Auswertung bekommt stattdessen einen
  // eigenen, dynamischen Text (siehe zeigeQuizErgebnis).
  const outroBloecke = bonusBloecke.slice(verbrauchteAnzahl);

  const buttonBlock = `<div class="quiz-start-wrap">
    <button class="quiz-start-button" id="quiz-start-button" type="button">📝 Lehrgangsprüfung ablegen</button>
  </div>`;

  const neueBloecke = [
    ...bloecke.slice(0, bonusStart),
    buttonBlock,
    ...outroBloecke,
    ...bloecke.slice(bonusEnde)
  ];

  return { bloecke: neueBloecke, quiz };
}

// Zerlegt die Blöcke eines BONUS-Abschnitts in: Titel, optionale
// Beschreibung und Fragen (mit Antwortoptionen). Alles NACH der letzten
// Frage (z.B. "Herzlichen Glückwunsch...") gehört nicht zum Quiz,
// sondern bleibt normaler Text auf der Buch-Seite - deswegen liefert
// diese Funktion zusätzlich "verbrauchteAnzahl", damit der Aufrufer
// weiß, ab welchem Index der restliche Text beginnt.
//
// Erwartetes Markdown-Muster pro Frage:
//   **1. Frage-Text?**
//
//   ☐ Option A
//   ☐ Option B
function parseQuizAusBloecken(bonusBloecke) {
  const titel = bonusBloecke[0]
    .replace(/^<h1>/, "")
    .replace(/<\/h1>$/, "")
    .replace(/^BONUS:?\s*/i, "")
    .trim();

  let i = 1;
  let beschreibung = null;

  if (bonusBloecke[i] && !/^<p><strong>\d+\./.test(bonusBloecke[i])) {
    beschreibung = bonusBloecke[i];
    i++;
  }

  const fragen = [];

  for (; i < bonusBloecke.length; i++) {
    const block = bonusBloecke[i];
    // NEU: Nummer als eigene Gruppe erfassen, damit sie im Quiz-Overlay
    // wieder angezeigt werden kann (statt sie beim Parsen zu verwerfen).
    const frageMatch = block.match(/^<p><strong>(\d+)\.\s*(.+?)<\/strong><\/p>$/);

    if (!frageMatch) {
      break;
    }

    const optionenBlock = bonusBloecke[i + 1] || "";
    const optionen = optionenBlock
      .replace(/^<p>/, "")
      .replace(/<\/p>$/, "")
      .split("<br>")
      .map(o => o.replace(/^☐\s*/, "").trim())
      .filter(Boolean);

    fragen.push({ nummer: frageMatch[1], text: frageMatch[2], optionen });
    i++;
  }

  return { titel, beschreibung, fragen, verbrauchteAnzahl: i };
}

// Baut den Button-Klick-Handler auf, der das Quiz-Overlay öffnet.
// Wird pro Buch-Seite einmal aufgerufen - tut nichts, falls kein
// BONUS-Abschnitt gefunden wurde.
function initQuizButton(quiz) {
  if (!quiz) return;

  const startButton = document.getElementById("quiz-start-button");
  if (!startButton) return;

  startButton.addEventListener("click", () => {
    baueQuizGeruest();
    zeigeQuizFragen(quiz);
    document.getElementById("quiz-overlay").classList.add("is-open");
  });
}

// Baut das Overlay-Grundgerüst einmalig und hängt es an den <body>
function baueQuizGeruest() {
  if (document.getElementById("quiz-overlay")) return;

  const overlay = document.createElement("div");
  overlay.id = "quiz-overlay";
  overlay.className = "quiz-overlay";
  overlay.innerHTML = `
    <button class="quiz-close" id="quiz-close" aria-label="Schließen">&times;</button>
    <div class="quiz-panel" id="quiz-panel"></div>
  `;

  document.body.appendChild(overlay);

  document.getElementById("quiz-close").addEventListener("click", schliesseQuiz);

  overlay.addEventListener("click", e => {
    if (e.target === overlay) schliesseQuiz();
  });

  document.addEventListener("keydown", e => {
    if (overlay.classList.contains("is-open") && e.key === "Escape") {
      schliesseQuiz();
    }
  });
}

function schliesseQuiz() {
  const overlay = document.getElementById("quiz-overlay");
  if (overlay) overlay.classList.remove("is-open");
}

// Zeigt die Fragen als Formular mit Checkboxen an. Erst beim Abschicken
// (Button "Auswertung anzeigen") wird die Auswertung eingeblendet - das
// komplette Panel wird dabei einfach neu befüllt (robuster als
// einzelne Elemente per "hidden" ein-/auszublenden).
function zeigeQuizFragen(quiz) {
  const panel = document.getElementById("quiz-panel");

  const beschreibungHtml = quiz.beschreibung || "";

  const fragenHtml = quiz.fragen.map((frage, fIndex) => `
    <fieldset class="quiz-frage">
      <legend><span class="quiz-nummer">${frage.nummer}</span>${frage.text}</legend>
      ${frage.optionen.map((option, oIndex) => `
        <label class="quiz-option">
          <input type="radio" name="quiz-frage-${fIndex}" value="${oIndex}" required>
          <span>${option}</span>
        </label>
      `).join("")}
    </fieldset>
  `).join("");

  panel.innerHTML = `
    <h3 class="quiz-titel">${quiz.titel}</h3>
    ${beschreibungHtml}
    <form id="quiz-form">
      ${fragenHtml}
      <button class="quiz-auswerten-button" type="submit">Auswertung anzeigen</button>
    </form>
  `;

  document.getElementById("quiz-form").addEventListener("submit", e => {
    e.preventDefault();
    zeigeQuizErgebnis(quiz);
  });
}

// Zeigt die Auswertung an - da Satire, gilt ohnehin jede Antwort als
// richtig: kleines gezeichnetes Abzeichen-Icon (statt des Buch-Covers,
// das als Kreis-Crop schlecht aussah), darunter stilisiertes
// "X/X Antworten richtig" (X = Anzahl der erkannten Fragen) und ein
// knapper Glückwunsch-Text mit dem BUCH-Titel (nicht dem Quiz-Titel).
// Zusätzlich ein "Zurück"-Button für alle, die nicht sehen (wollen),
// dass ein Klick daneben das Overlay auch schließt.
function zeigeQuizErgebnis(quiz) {
  const panel = document.getElementById("quiz-panel");
  const anzahl = quiz.fragen.length;

  panel.innerHTML = `
    <div class="quiz-ergebnis-abzeichen" aria-hidden="true">
      <svg viewBox="0 0 100 120" width="84" height="101">
        <path d="M35 68 L18 116 L50 99 L82 116 L65 68 Z" fill="var(--color-accent-warm)"></path>
        <circle cx="50" cy="45" r="40" fill="var(--color-accent)" stroke="#fff" stroke-width="4"></circle>
        <path d="M50 24 L56.5 38.5 L72 40.5 L60.5 51 L63.5 66.5 L50 58.5 L36.5 66.5 L39.5 51 L28 40.5 L43.5 38.5 Z" fill="#fff"></path>
      </svg>
    </div>

    <p class="quiz-score">${anzahl}/${anzahl} Antworten richtig</p>

    <div class="quiz-ergebnis-text">
      <p>
        Herzlichen Glückwunsch!
        Du bist Experte zum Thema <strong>${buch.titel}</strong>!
      </p>
    </div>

    <div class="quiz-ergebnis-buttons">
      <button
        class="quiz-zurueck-button"
        id="quiz-zertifikat-button"
        type="button">
        Zertifikat erstellen
      </button>

      <button
        class="quiz-zurueck-button"
        id="quiz-zurueck-button"
        type="button">
        Zurück
      </button>
    </div>
  `;

  document
    .getElementById("quiz-zurueck-button")
    .addEventListener("click", schliesseQuiz);

  document
    .getElementById("quiz-zertifikat-button")
    .addEventListener("click", () => {
      zeigeZertifikatDialog(anzahl, quiz);
    });
}

function zeigeZertifikatDialog(anzahl, quiz) {
  const panel = document.getElementById("quiz-panel");

  panel.innerHTML = `
    <h3>Zertifikat erstellen</h3>

    <p>
      Bitte gib deinen Namen ein, der auf dem Zertifikat erscheinen soll.
    </p>

    <p class="quiz-zertifikat-hinweis">
      Name des zukünftigen Zertifikatsträgers:
    </p>

    <input
      id="zertifikat-name"
      type="text"
      placeholder="Max Mustermann"
      class="quiz-name-input">

    <div class="quiz-ergebnis-buttons">
      <button
        id="zertifikat-erstellen"
        class="quiz-zurueck-button"
        type="button">
        Zertifikat herunterladen
      </button>

      <button
        id="zertifikat-zurueck"
        class="quiz-zurueck-button"
        type="button">
        Zurück
      </button>
    </div>
  `;

  document
    .getElementById("zertifikat-zurueck")
    .addEventListener("click", () => zeigeQuizErgebnis(quiz));

  document
    .getElementById("zertifikat-erstellen")
    .addEventListener("click", () => {

      const name =
        document.getElementById("zertifikat-name").value.trim();

      if (!name) {
        alert("Bitte gib einen Namen ein.");
        return;
      }

      erstelleZertifikat(name, anzahl);
    });
}

const zertifikatsNummer =
  "MI-" +
  new Date().getFullYear() +
  "-" +
  Math.floor(Math.random() * 100000)
    .toString()
    .padStart(5, "0");

function erstelleZertifikat(name, anzahl) {

  const lehrgang =
    buch.lehrgang ||
    buch.titel ||
    buch.slug;

  const zertifikat = document.createElement("div");

  zertifikat.style.width = "1200px";
  zertifikat.style.padding = "80px";
  zertifikat.style.background = "#f7f4ec";
  zertifikat.style.color = "#1f2747";
  zertifikat.style.fontFamily = "Georgia, serif";
  zertifikat.style.border = "10px solid #c22d2d";
  zertifikat.style.position = "fixed";
  zertifikat.style.left = "-99999px";

  zertifikat.innerHTML = `
    <p style="font-size:14px;color:#666;">
      Zertifikatsnummer: ${zertifikatsNummer}
    </p>

    <div style="text-align:center">

      <img
        src="assets/favicon/methodius-512x512-nobg.png"
        alt="Methodius-Institut"
        style="
          width:120px;
          height:auto;
          margin:25px auto 35px;
          display:block;
        ">

      <h2 style="margin-bottom:10px">
        Methodius-Institut für angewandte Lebenswissenschaften
      </h2>
      <br>

      <div
        style="
          display:flex;
          align-items:center;
          justify-content:center;
          margin:30px 0;
        ">
        
        <div
          style="
            width:140px;
            height:3px;
            background:#B5292C;
          ">
        </div>

        <div
          style="
            width:20px;
            height:20px;
            background:#B5292C;
            transform:rotate(45deg);
            margin:0 20px;
          ">
        </div>

        <div
          style="
            width:140px;
            height:3px;
            background:#B5292C;
          ">
        </div>

      </div>

      <div
        style="
          font-size:72px;
          font-weight:700;
          letter-spacing:8px;
          margin:30px 0 50px;
          text-transform:uppercase;
          color:#B5292C;
        ">
        Zertifikat
      </div>

      <br>

      <p>Hiermit wird bestätigt, dass</p>

      <h1>${name}</h1>

      <p
        style="
          margin-top:35px;
          margin-bottom:15px;
          color:#666;
        ">
        den Lehrgang
      </p>

      <div
        style="
          font-size:52px;
          font-weight:700;
          line-height:1.15;

          color:#B5292C;

          max-width:900px;
          margin:0 auto;

          font-style:italic;
        ">
        ${lehrgang}
      </div>

      <div
        style="
          display:flex;
          align-items:center;
          justify-content:center;
          margin:25px 0 45px;
        ">

        <div style="width:100px;height:2px;background:#B5292C;"></div>

        <div
          style="
            width:14px;
            height:14px;
            background:#B5292C;
            transform:rotate(45deg);
            margin:0 16px;
          ">
        </div>

        <div style="width:100px;height:2px;background:#B5292C;"></div>

      </div>

      <p>mit der Höchstpunktzahl von</p>

      <h2>${anzahl} von ${anzahl} Punkten</h2>

      <p>erfolgreich abgeschlossen hat.</p>

      <br>

      <p>
        Die Möglichkeit eines Nichtbestehens
        war im Prüfungsverfahren nicht vorgesehen.
      </p>

      <p>
        Ausgestellt durch das
        Methodius-Institut für angewandte Lebenswissenschaften.
      </p>

      <br>
      
      <div
        style="
          display:flex;
          align-items:center;
          justify-content:center;
          margin:30px 0;
        ">
        
        <div
          style="
            width:140px;
            height:3px;
            background:#B5292C;
          ">
        </div>

        <div
          style="
            width:20px;
            height:20px;
            background:#B5292C;
            transform:rotate(45deg);
            margin:0 20px;
          ">
        </div>

        <div
          style="
            width:140px;
            height:3px;
            background:#B5292C;
          ">
        </div>

      </div>
      
      <br>

      <div style="margin-top:80px">

        <p class="autor-signatur">
          ${AUTOR_SIGNATUR_TEXT}
        </p>

        <p class="autor-name">
          Dr. Maximilian Methodius
        </p>

      </div>
    </div>
  `;

  document.body.appendChild(zertifikat);

  html2canvas(zertifikat, {
    scale: 2
  }).then(canvas => {

    const link = document.createElement("a");

    link.download =
      `methodius-zertifikat-${name
        .replace(/\s+/g, "-")
        .toLowerCase()}.png`;

    link.href = canvas.toDataURL("image/png");

    link.click();

    zertifikat.remove();
  });
}

/* ============================================
   COVER-LIGHTBOX
   Klick auf das Cover-Bild zeigt es vergrößert in einem Overlay.
   ============================================ */

function initCoverLightbox(bildId = "buch-cover-front") {
  const bild = document.getElementById(bildId);

  if (!bild) {
    return;
  }
  if (!bild) return;

  bild.addEventListener("click", () => {
    baueLightboxGeruest();

    const overlayBild =
      document.getElementById("cover-lightbox-bild");

    overlayBild.src = bild.src;
    overlayBild.alt = bild.alt;

    document
      .getElementById("cover-lightbox-overlay")
      .classList.add("is-open");
  });
}

// Baut das Lightbox-Grundgerüst einmalig und hängt es an den <body>
function baueLightboxGeruest() {
  if (
    document.getElementById("cover-lightbox-overlay")
  ) {
    return;
  }

  const overlay = document.createElement("div");

  overlay.id = "cover-lightbox-overlay";
  overlay.className = "cover-lightbox-overlay";

  overlay.innerHTML = `
    <button class="cover-lightbox-close" id="cover-lightbox-close" aria-label="Schließen">&times;</button>
    <img id="cover-lightbox-bild" src="" alt="">
  `;

  document.body.appendChild(overlay);

  document
    .getElementById("cover-lightbox-close")
    .addEventListener("click", schliesseLightbox);

  overlay.addEventListener("click", e => {
    if (e.target === overlay) {
      schliesseLightbox();
    }
  });

  document.addEventListener("keydown", e => {
    if (
      overlay.classList.contains("is-open") &&
      e.key === "Escape"
    ) {
      schliesseLightbox();
    }
  });
}

function schliesseLightbox() {
  const overlay =
    document.getElementById("cover-lightbox-overlay");

  if (overlay) {
    overlay.classList.remove("is-open");
  }
}

/* ============================================
   BLÄTTER-ANSICHT
   Zeigt den Ratgeber-Text zweiseitig wie ein aufgeschlagenes Heft,
   mit Pfeilen zum Vor- und Zurückblättern.
   ============================================ */

let flipSeiten = [];
let flipIndex = 0;
let flipBloeckeOhneTrennlinie = [];
let flipResizeTimeout = null;

// Im Hochformat wird bewusst nur EINE Seite auf einmal gezeigt (statt
// zwei nebeneinander/übereinander) - das lässt sich besser lesen und
// die einzelne Seite kann viel mehr von der verfügbaren Höhe nutzen.
function istPortraitModus() {
  return window.matchMedia("(orientation: portrait)").matches;
}

function berechneFlipSeiten() {
  flipSeiten = teileInSeiten(flipBloeckeOhneTrennlinie);
}

function initFlipbook(bloecke) {
  baueFlipbookGeruest();

  // <hr> wird im Blättermodus nicht gebraucht:
  // neue Kapitel beginnen ohnehin automatisch auf einer neuen Seite.
  flipBloeckeOhneTrennlinie =
    bloecke.filter(block => block !== "<hr>");

  document
    .getElementById("blaettern-link")
    .addEventListener("click", e => {
      e.preventDefault();

      // Erst JETZT (statt schon beim Laden der Seite) berechnen, damit
      // die aktuelle Bildschirmgröße/Ausrichtung berücksichtigt wird.
      berechneFlipSeiten();
      flipIndex = 0;
      zeigeSpread();

      document
        .getElementById("flipbook-overlay")
        .classList.add("is-open");
    });
}

// Baut das Overlay-Grundgerüst einmalig und hängt es an den <body>,
function baueFlipbookGeruest() {
  if (document.getElementById("flipbook-overlay")) {
    return;
  }

  const overlay = document.createElement("div");

  overlay.id = "flipbook-overlay";
  overlay.className = "flipbook-overlay";

  overlay.innerHTML = `
    <button class="flipbook-close" id="flipbook-close" aria-label="Schließen">&times;</button>

    <div class="flipbook-stage">
      <button class="flipbook-arrow" id="flipbook-prev" aria-label="Vorherige Seite">&#8249;</button>

      <div>
        <div class="flipbook-book">
          <div class="flipbook-page" id="flipbook-page-links"></div>
          <div class="flipbook-page" id="flipbook-page-rechts"></div>
        </div>

        <div class="flipbook-counter" id="flipbook-counter"></div>
      </div>

      <button class="flipbook-arrow" id="flipbook-next" aria-label="Nächste Seite">&#8250;</button>
    </div>
  `;

  document.body.appendChild(overlay);

  document
    .getElementById("flipbook-close")
    .addEventListener("click", schliesseFlipbook);

  overlay.addEventListener("click", e => {
    if (e.target === overlay) {
      schliesseFlipbook();
    }
  });

  document
    .getElementById("flipbook-prev")
    .addEventListener("click", () => blaettere(-1));

  document
    .getElementById("flipbook-next")
    .addEventListener("click", () => blaettere(1));

  document.addEventListener("keydown", e => {
    if (!overlay.classList.contains("is-open")) {
      return;
    }

    if (e.key === "ArrowLeft") {
      blaettere(-1);
    }

    if (e.key === "ArrowRight") {
      blaettere(1);
    }

    if (e.key === "Escape") {
      schliesseFlipbook();
    }
  });

  // Bei Größenänderung (z.B. Drehen des Handys) die Seitenaufteilung
  // neu berechnen, solange das Overlay offen ist - sonst passt die
  // vorher berechnete Aufteilung nicht mehr zur neuen Seitengröße.
  // Leicht entprellt (200ms), damit das nicht bei jedem Zwischenschritt
  // der Dreh-Animation feuert.
  window.addEventListener("resize", () => {
    clearTimeout(flipResizeTimeout);
    flipResizeTimeout = setTimeout(() => {
      if (!overlay.classList.contains("is-open")) return;

      berechneFlipSeiten();
      // Sicherstellen, dass der aktuelle Index nach der Neuberechnung
      // noch existiert (z.B. falls es jetzt insgesamt weniger Seiten gibt).
      if (flipIndex >= flipSeiten.length) {
        flipIndex = Math.max(0, flipSeiten.length - 1);
      }
      zeigeSpread();
    }, 200);
  });
}

function schliesseFlipbook() {
  document
    .getElementById("flipbook-overlay")
    .classList.remove("is-open");
}

// "richtung" ist -1 (zurück) oder 1 (vor). Im Hochformat wird pro
// Klick EINE Seite weitergeblättert, sonst ZWEI (da dort immer ein
// ganzer Spread aus linker+rechter Seite gezeigt wird).
function blaettere(richtung) {
  const schritt = (istPortraitModus() ? 1 : 2) * richtung;
  const neuerIndex = flipIndex + schritt;

  if (
    neuerIndex < 0 ||
    neuerIndex >= flipSeiten.length
  ) {
    return;
  }

  flipIndex = neuerIndex;
  zeigeSpread();
}

// Verteilt die Text-Blöcke auf Seiten: Ein unsichtbares Mess-Element in
// exakter .flipbook-page-Größe wird nach und nach befüllt; sobald der
// Inhalt nicht mehr hineinpasst, beginnt eine neue Seite.
//
// WICHTIG: Die Mess-Box bekommt bewusst KEINE fest einprogrammierten
// Maße (früher: immer 480x660px) - stattdessen übernimmt sie ganz
// normal die Maße aus der .flipbook-page-CSS-Klasse, die sich per
// Media Queries an Bildschirmgröße/Ausrichtung anpasst. Nur so
// entspricht die Seitenaufteilung dem, was auf dem jeweiligen Gerät
// tatsächlich sichtbar ist - sonst wird z.B. auf dem Handy Text
// abgeschnitten, der für eine viel größere Desktop-Seite berechnet wurde.
function teileInSeiten(bloecke) {
  // WICHTIG: Die Mess-Seite braucht denselben Flexbox-Kontext wie die
  // echte Seite (.flipbook-book > .flipbook-page), sonst greift weder
  // "flex: 1 1 50%" noch die Höhe aus dem Flexbox-Stretch-Verhalten -
  // eine freistehende .flipbook-page hätte gar keine echte
  // Breitenbegrenzung und würde Text viel zu wenig umbrechen
  // (funktioniert nur "zufällig" halbwegs auf breiten Desktop-
  // Bildschirmen, bricht aber auf schmalen Handy-Seiten komplett
  // zusammen: zu viel Inhalt wird pro Seite berechnet, der Rest wird
  // auf der echten, schmalen Seite per overflow:hidden abgeschnitten
  // und beim Blättern einfach übersprungen).
  const messBuch = document.createElement("div");
  messBuch.className = "flipbook-book flipbook-measure-book";
  messBuch.style.position = "absolute";
  messBuch.style.visibility = "hidden";
  messBuch.style.pointerEvents = "none";
  messBuch.style.left = "-10000px";
  messBuch.style.top = "0";

  const messSeite = document.createElement("div");
  messSeite.className = "flipbook-page flipbook-measure-page";
  messBuch.appendChild(messSeite);

  // Im Zwei-Seiten-Modus (Querformat) bekommt .flipbook-page über
  // "flex: 1 1 50%" nur die HALBE Buchbreite - mit nur einer Seite im
  // Mess-Buch würde sie stattdessen dank flex-grow die GANZE
  // Buchbreite einnehmen (doppelt so breit wie in Wirklichkeit). Eine
  // leere zweite Seite daneben sorgt dafür, dass sich beide wie im
  // echten Buch die Breite teilen. Im Hochformat (eine Seite, volle
  // Breite per flex-basis:100%) ist das nicht nötig.
  if (!istPortraitModus()) {
    const platzhalterSeite = document.createElement("div");
    platzhalterSeite.className = "flipbook-page";
    messBuch.appendChild(platzhalterSeite);
  }

  document.body.appendChild(messBuch);

  const seiten = [];
  let aktuelleSeite = [];

  function passtAufSeite(html) {
    messSeite.innerHTML =
      aktuelleSeite.join("\n") + html;

    return (
      messSeite.scrollHeight <=
      messSeite.clientHeight
    );
  }

  function neueSeite() {
    if (aktuelleSeite.length > 0) {
      seiten.push(aktuelleSeite);
    }

    aktuelleSeite = [];
    messSeite.innerHTML = "";
  }

  bloecke.forEach(block => {
    const istKapitelStart =
      block.startsWith("<h1") || block.startsWith("<h2");

    /*
     * Kapitelüberschriften beginnen weiterhin auf einer neuen Seite.
     */
    if (
      istKapitelStart &&
      aktuelleSeite.length > 0
    ) {
      neueSeite();
    }

    /*
     * Normale Blöcke:
     * Absatz, Überschrift, Zitat etc.
     */
    if (
      !block.startsWith("<ul>") &&
      !block.startsWith("<ol>")
    ) {
      if (
        !passtAufSeite(block) &&
        aktuelleSeite.length > 0
      ) {
        neueSeite();
      }

      aktuelleSeite.push(block);

      messSeite.innerHTML =
        aktuelleSeite.join("\n");

      return;
    }

    /*
     * LISTEN:
     * Die Liste wird in einzelne <li>-Elemente zerlegt.
     */
    const istUl = block.startsWith("<ul>");
    const tag = istUl ? "ul" : "ol";

    const match = block.match(
      new RegExp(
        `<${tag}>([\\s\\S]*?)<\\/${tag}>`
      )
    );

    if (!match) {
      aktuelleSeite.push(block);
      messSeite.innerHTML =
        aktuelleSeite.join("\n");
      return;
    }

    const listenInhalt = match[1];

    const items =
      listenInhalt.match(
        /<li>[\s\S]*?<\/li>/g
      ) || [];

    let aktuelleListe = [];

    items.forEach(item => {
      const testListe = `
        <${tag}>
          ${aktuelleListe.join("\n")}
          ${item}
        </${tag}>
      `;

      const testInhalt =
        aktuelleSeite.concat(testListe);

      messSeite.innerHTML =
        testInhalt.join("\n");

      /*
       * Passt der nächste Eintrag nicht mehr:
       */
      if (
        messSeite.scrollHeight >
          messSeite.clientHeight &&
        aktuelleListe.length > 0
      ) {
        aktuelleSeite.push(`
          <${tag}>
            ${aktuelleListe.join("\n")}
          </${tag}>
        `);

        neueSeite();

        aktuelleListe = [item];

        messSeite.innerHTML = `
          <${tag}>
            ${item}
          </${tag}>
        `;

        return;
      }

      aktuelleListe.push(item);
    });

    /*
     * Übrig gebliebene Listeneinträge an die aktuelle Seite hängen.
     */
    if (aktuelleListe.length > 0) {
      const fertigeListe = `
        <${tag}>
          ${aktuelleListe.join("\n")}
        </${tag}>
      `;

      aktuelleSeite.push(fertigeListe);

      messSeite.innerHTML =
        aktuelleSeite.join("\n");
    }
  });

  if (aktuelleSeite.length > 0) {
    seiten.push(aktuelleSeite);
  }

  document.body.removeChild(messBuch);

  return seiten.length > 0
    ? seiten
    : [[]];
}

// Zeigt die aktuelle(n) Seite(n) an: im Hochformat nur EINE Seite,
// sonst einen Spread aus linker + rechter Seite.
function zeigeSpread() {
  const linkeSeite =
    document.getElementById(
      "flipbook-page-links"
    );

  const rechteSeite =
    document.getElementById(
      "flipbook-page-rechts"
    );

  const zaehler =
    document.getElementById(
      "flipbook-counter"
    );

  const prevBtn =
    document.getElementById(
      "flipbook-prev"
    );

  const nextBtn =
    document.getElementById(
      "flipbook-next"
    );

  const einzelseite = istPortraitModus();
  const schritt = einzelseite ? 1 : 2;

  const inhaltLinks =
    flipSeiten[flipIndex] || [];

  linkeSeite.innerHTML =
    inhaltLinks.join("\n") +
    `<span class="flipbook-page-number">${flipIndex + 1}</span>`;

  if (einzelseite) {
    // Rechte Seite bleibt leer (und ist per CSS im Hochformat
    // ohnehin ausgeblendet) - es wird immer nur eine Seite gezeigt.
    rechteSeite.innerHTML = "";
    zaehler.textContent = `Seite ${flipIndex + 1} von ${flipSeiten.length}`;
  } else {
    const inhaltRechts =
      flipSeiten[flipIndex + 1] || [];

    rechteSeite.innerHTML =
      inhaltRechts.length
        ? inhaltRechts.join("\n") +
          `<span class="flipbook-page-number">${flipIndex + 2}</span>`
        : "";

    zaehler.textContent =
      inhaltRechts.length
        ? `Seite ${flipIndex + 1}–${flipIndex + 2} von ${flipSeiten.length}`
        : `Seite ${flipIndex + 1} von ${flipSeiten.length}`;
  }

  prevBtn.disabled =
    flipIndex <= 0;

  nextBtn.disabled =
    flipIndex + schritt >= flipSeiten.length;
}
/*
  Liste aller Ratgeber.

  Zwei Schreibweisen sind möglich:

  1) Einfacher Text, wenn Dateiname und Anzeige-Titel identisch sind:
       "Mein Buchtitel"
     -> erwartet Dateien pics/ratgeber/Mein Buchtitel.png und
     md/ratgeber/Mein Buchtitel.md

  2) Objekt, wenn sich Dateiname (slug) und Anzeige-Titel (titel)
     unterscheiden sollen, z.B. für einen kürzeren/saubereren Dateinamen:
       { slug: "mein-buch", titel: "Mein ausführlicher Buchtitel!" }
     -> erwartet Dateien pics/ratgeber/mein-buch.png und
    md/ratgeber/mein-buch.md
     "titel" ist dabei optional - fehlt er, wird einfach "slug" als
     Anzeige-Titel verwendet (wie bei der einfachen Text-Schreibweise
     oben):
       { slug: "mein-buch", erstellt: "12. März 2026" }
     -> Anzeige-Titel wird "mein-buch"

  Optional lässt sich bei der Objekt-Schreibweise zusätzlich "erstellt",
  "aktualisiert" und/oder "einsender" angeben (einfache Strings, z.B.
  "12. März 2026" - das Format ist frei wählbar, es wird 1:1 auf der
  Buch-Seite angezeigt):
       { slug: "mein-buch", titel: "Mein Buch", erstellt: "12. März 2026" }
       { slug: "mein-buch", titel: "Mein Buch", erstellt: "12. März 2026", aktualisiert: "3. April 2026" }
       { slug: "mein-buch", titel: "Mein Buch", erstellt: "12. März 2026", einsender: "Max Mustermann" }
     Ist "erstellt" gesetzt, erscheint oben auf der Buch-Seite
     "Veröffentlicht: ...". Ist zusätzlich (oder auch nur) "aktualisiert"
     gesetzt, erscheint "Aktualisiert: ..." darunter. Ist "einsender"
     gesetzt, erscheint zusätzlich ganz oben (über "Veröffentlicht: ...")
     die Zeile "Vorgeschlagen von: ...". Alle drei Angaben sind komplett
     optional und werden weggelassen, wenn nicht vorhanden.

  Neue Bücher fügst du einfach am ENDE der Liste hinzu –
  "Neueste Ratgeber" zeigt automatisch die letzten Einträge.
*/
const ratgeberRohdaten = [
  {slug: "Abnehmen dank Muskelabbau", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "Freunde verlieren leicht gemacht", erstellt: "2026-08-30", kategorie: RatgeberKategorie.GESELLSCHAFT},
  {slug: "Das perfekte Leben auf Social Media", erstellt: "2026-08-30", kategorie: RatgeberKategorie.MEDIEN},
  {slug: "Die Kunst, beschäftigt auszusehen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "KI (gar nicht) sicher nutzen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Moderne Kunst interpretieren", erstellt: "2026-08-30", kategorie: RatgeberKategorie.KUNST_KULTUR},
  {slug: "Vom Millionär zum Tellerwäscher in nur 7 Tagen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "In 12 einfachen Schritten zum US-Präsidenten", erstellt: "2026-08-30", kategorie: RatgeberKategorie.GESELLSCHAFT},
  {slug: "So wirst du zum modernen Künstler", erstellt: "2026-08-30", kategorie: RatgeberKategorie.KUNST_KULTUR},
  {slug: "Smalltalk für Fortgeschrittene", erstellt: "2026-08-30", kategorie: RatgeberKategorie.GESELLSCHAFT},
  {slug: "Stress reduzieren durch Faulheit", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "Politische Bildung durch soziale Medien", erstellt: "2026-08-30", kategorie: RatgeberKategorie.MEDIEN},
  {slug: "Intelligent werden mit KI", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Muskelkater ohne Training", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "Kunstkritiker werden in nur 15 Minuten", erstellt: "2026-08-30", kategorie: RatgeberKategorie.KUNST_KULTUR},
  {slug: "Erfolgreich werden ohne Leistung", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Aluhüte im Alltag richtig verwenden", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Warum beim Nachbarn das Gras immer viel grüner ist", erstellt: "2026-08-30", kategorie: RatgeberKategorie.GESELLSCHAFT},
  {slug: "Termine vermeiden leicht gemacht", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Zum Influencer in nur 2 Stunden", erstellt: "2026-08-30", kategorie: RatgeberKategorie.MEDIEN},
  {slug: "Wie man jedes Buch als gesellschaftskritisch interpretiert", erstellt: "2026-08-30", kategorie: RatgeberKategorie.KUNST_KULTUR},
  {slug: "Experte werden durch selbstbewusstes Auftreten", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Wir haben das sicherste Passwort", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Freunde finden in Dating-Portalen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.GESELLSCHAFT}, 
  {slug: "Warum ein Passwort für alles reicht", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Glücklich werden durch niedrigere Erwartungen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "Der perfekte Körper dank geschickter Beleuchtung", erstellt: "2026-08-30", kategorie: RatgeberKategorie.MEDIEN},
  {slug: "Ratgeber schreiben mit KI", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK}, 
  {slug: "Meetings überleben ohne Expertise", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF}, 
  {slug: "Meisterwerke erkennen am Preisetikett", erstellt: "2026-08-30", kategorie: RatgeberKategorie.KUNST_KULTUR}, 
  {slug: "Quellenangaben erfinden für Fortgeschrittene", erstellt: "2026-08-30", kategorie: RatgeberKategorie.MEDIEN}, 
  {slug: "Wie man zuverlässig unzuverlässig wird", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Gedanken lesen durch geschicktes Raten", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Statistiken fälschen leicht gemacht", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Die Kunst, am Monatsanfang schon pleite zu sein", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "So beweist man, dass die globale Erwärmung erfunden ist", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Pünktlichkeit verbessern durch Zugausfälle", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Diskussionen gewinnen durch konsequentes Dagegenreden", erstellt: "2026-08-30", kategorie: RatgeberKategorie.GESELLSCHAFT},
  {slug: "Warum das Leben leichter ist, wenn man nichts versteht", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "Warum ich heute leider keine Zeit habe", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Wie man aus Junk-Food Gourmet-Menüs bastelt", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "Sicherheit beim Bewerbungsgespräch trotz Mangel an Fachwissen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Plötzlich Privatdetektiv - Völlig unverdächtige Leute observieren", erstellt: "2026-08-30", kategorie: RatgeberKategorie.GESELLSCHAFT},
  {slug: "Zugausfälle als Chance nutzen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Unsinn mit wissenschaftlichen Diagrammen belegen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Permanente Enttäuschung dank zu hoch gesteckter Ziele", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "Befördert werden ohne Qualifikation", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Verwendung von KI durch Fehler vertuschen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.WISSEN_TECHNIK},
  {slug: "Die besten Ausreden für Verspätungen", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Wie man aus einer kleinen Aufgabe ein Großprojekt macht", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Komplimente machen, die garantiert falsch verstanden werden", erstellt: "2026-08-30", kategorie: RatgeberKategorie.LEBEN},
  {slug: "E-Mails schreiben, die niemand beantworten möchte", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Wie man beim ersten Eindruck einen bleibenden Schaden hinterlässt", erstellt: "2026-08-30", kategorie: RatgeberKategorie.GESELLSCHAFT},
  {slug: "Smalltalk ohne Worte beenden", erstellt: "2026-08-30", kategorie: RatgeberKategorie.ALLTAG_BERUF},
  {slug: "Texte kurz und knackig halten", erstellt: "2026-08-30", kategorie: RatgeberKategorie.MEDIEN},
];

// Wandelt die Rohdaten oben in einheitliche { slug, titel, ... }-Objekte
// um, damit buchgrid.js und buch.js sich um nichts Zusätzliches kümmern
// müssen. Objekt-Einträge (inkl. optionalem "erstellt"/"aktualisiert"/
// "einsender") werden dabei unverändert durchgereicht - fehlt "titel",
// wird "slug" als Anzeige-Titel verwendet.
const ratgeberListe = ratgeberRohdaten.map(eintrag =>
  typeof eintrag === "string"
    ? { slug: eintrag, titel: eintrag }
    : { ...eintrag, titel: eintrag.titel || eintrag.slug }
);
